<?php
require 'config.php';
if (is_logged_in()) { header('Location: ' . (is_admin() ? 'admin/dashboard.php' : 'index.php')); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'user'");
    $stmt->execute([strtolower(trim($_POST['email'] ?? ''))]);
    $u = $stmt->fetch();
    if ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['name']    = $u['full_name'];
        $_SESSION['email']   = $u['email'];
        $_SESSION['role']    = 'user';
        header('Location: index.php?page=booking'); exit;
    }
    $error = 'Incorrect email or password.';
}
$title = 'Patient Login'; include 'includes/auth_head.php'; ?>
  <div class="auth-icon"><i class="fa-solid fa-user"></i></div>
  <h2>Welcome back</h2>
  <p class="auth-sub">Log in to book and manage your appointments</p>
  <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($error) ?></div></div><?php endif; ?>
  <form method="post">
    <div class="form-group"><label>Email</label><input type="email" class="form-control" name="email" placeholder="you@example.com" value="<?= e($_POST['email'] ?? '') ?>" required autofocus></div>
    <div class="form-group"><label>Password</label>
      <div class="pw"><input type="password" class="form-control" name="password" id="pw" placeholder="Your password" required>
      <button type="button" onclick="var f=document.getElementById('pw');f.type=f.type==='password'?'text':'password'" tabindex="-1"><i class="fa-solid fa-eye"></i></button></div></div>
    <button class="btn btn-block" type="submit"><i class="fa-solid fa-right-to-bracket"></i> Login</button>
  </form>
  <p class="auth-links">New here? <a href="register.php">Create an account</a><br><a href="admin/login.php" style="font-weight:500"><i class="fa-solid fa-shield-halved"></i> Admin login</a></p>
<?php include 'includes/auth_foot.php';
