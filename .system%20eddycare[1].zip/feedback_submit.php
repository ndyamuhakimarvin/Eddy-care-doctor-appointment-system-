<?php
require 'config.php';
require 'includes/mailer.php';
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: index.php?page=feedback'); exit; }

$name    = trim($_POST['name'] ?? '');
$rating  = (int)($_POST['rating'] ?? 0);
$message = trim($_POST['message'] ?? '');
$doctor  = (int)($_POST['doctor_id'] ?? 0) ?: null;

if ($name === '' || $message === '' || $rating < 1 || $rating > 5) {
    flash('error', 'Please fill in your name, a rating and your feedback.');
} else {
    $uid = $_SESSION['user_id'] ?? null;
    $pdo->prepare('INSERT INTO feedback (user_id, doctor_id, name, rating, message) VALUES (?,?,?,?,?)')
        ->execute([$uid, $doctor, $name, $rating, $message]);
    notify_feedback($uid, $doctor, $name, $rating, $message);   // confirmation to the patient + note to the doctor
    flash('success', 'Thank you for your feedback! We appreciate your input.' . ($uid ? ' A confirmation has been emailed to you.' : ''));
}
header('Location: index.php?page=feedback');
