<?php
/* EddyCare health check. Open:  /diagnose.php?key=YOUR_DIAG_KEY   (key is in config.php)
   Add &mailto=you@example.com to also send a real test email and see the exact SMTP error.
   DELETE THIS FILE once everything works. */
require 'config.php';
if (!isset($_GET['key']) || !hash_equals(DIAG_KEY, (string)$_GET['key'])) { http_response_code(404); exit('Not found'); }
header('Content-Type: text/html; charset=utf-8');

$rows = [];
function chk($label, $ok, $detail = '') { global $rows; $rows[] = [$label, $ok, $detail]; }

chk('PHP version', version_compare(PHP_VERSION, '7.4', '>='), PHP_VERSION);
foreach (['pdo_mysql', 'openssl', 'mbstring', 'session'] as $ext)
    chk("PHP extension: $ext", extension_loaded($ext), extension_loaded($ext) ? 'loaded' : ($ext === 'mbstring' ? 'missing (site uses a safe fallback)' : 'MISSING - ask your host to enable it'));
chk('Session works', session_id() !== '', session_id() !== '' ? 'ok' : 'no session');
chk('PHPMailer files present', is_file(__DIR__ . '/emailphp/PHPMailer-master/src/PHPMailer.php'));
foreach (['includes/header.php','includes/footer.php','includes/navbar.php','includes/sidebar.php','includes/auth_head.php','includes/auth_foot.php','includes/mailer.php','includes/theme.php','includes/verification.php'] as $f)
    chk("File $f", is_file(__DIR__ . '/' . $f));

chk('Database connection', true, DB_NAME);
$tables = ['users','doctors','appointments','feedback','settings','email_verification'];
foreach ($tables as $t) {
    try { $n = (int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); chk("Table $t", true, "$n rows"); }
    catch (Throwable $e) { chk("Table $t", false, 'MISSING - run migrate.sql in phpMyAdmin'); }
}
foreach ([['users','email_verified'],['doctors','email']] as [$t,$c]) {
    try { $pdo->query("SELECT `$c` FROM `$t` LIMIT 1"); chk("Column $t.$c", true); }
    catch (Throwable $e) { chk("Column $t.$c", false, 'MISSING - run migrate.sql in phpMyAdmin'); }
}
try {
    $roles = $pdo->query("SELECT role, COUNT(*) c FROM users GROUP BY role")->fetchAll(PDO::FETCH_KEY_PAIR);
    chk('Patients / admins', true, ($roles['user'] ?? 0) . ' patients, ' . ($roles['admin'] ?? 0) . ' admins');
    $unv = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin' AND email_verified=0")->fetchColumn();
    chk('Unverified admins', $unv === 0, $unv ? "$unv waiting for email verification" : 'none');
    $de = (int)$pdo->query("SELECT COUNT(*) FROM doctors WHERE email IS NOT NULL AND email<>''")->fetchColumn();
    $dt = (int)$pdo->query("SELECT COUNT(*) FROM doctors")->fetchColumn();
    chk('Doctors with an email', $de === $dt && $dt > 0, "$de of $dt (add the rest under Admin > Doctors)");
} catch (Throwable $e) { chk('User/doctor check', false, $e->getMessage()); }

// Can a patient be registered? Try the real INSERT, then undo it.
try {
    $pdo->beginTransaction();
    $pdo->prepare('INSERT INTO users (full_name,email,phone,password) VALUES (?,?,?,?)')
        ->execute(['Diag Test', 'diag-' . time() . '@example.invalid', '000', password_hash('x', PASSWORD_DEFAULT)]);
    $id = $pdo->lastInsertId();
    $ok = $pdo->query("SELECT COUNT(*) FROM users WHERE id=$id AND role='user'")->fetchColumn() == 1;
    $pdo->rollBack();
    chk('Patient registration (insert + undo)', $ok, $ok ? 'works' : 'insert did not produce a patient row');
} catch (Throwable $e) { if ($pdo->inTransaction()) $pdo->rollBack(); chk('Patient registration (insert + undo)', false, $e->getMessage()); }
chk('Password hashing', password_verify('abc', password_hash('abc', PASSWORD_DEFAULT)));

// Can we reach the mail server?
$errno = 0; $errstr = '';
$ctx = stream_context_create(['ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
$fp = @stream_socket_client('ssl://' . MAIL_HOST . ':' . MAIL_PORT, $errno, $errstr, 8, STREAM_CLIENT_CONNECT, $ctx);
chk('Mail server reachable + certificate valid', (bool)$fp, $fp ? MAIL_HOST . ':' . MAIL_PORT : "$errstr ($errno) - try the host name shown in cPanel > Email Accounts > Connect Devices");
if ($fp) fclose($fp);

$mailMsg = '';
if (!empty($_GET['mailto'])) {
    require 'includes/mailer.php';
    $ok = send_mail($_GET['mailto'], 'Test', 'EddyCare diagnose test', 'Email is working', '<p>This test message was sent from <code>diagnose.php</code>.</p>');
    $mailMsg = $ok ? 'SENT to ' . e($_GET['mailto']) : 'FAILED: ' . e(mail_last_error());
    chk('Test email', $ok, $mailMsg);
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8"><title>EddyCare diagnose</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{font-family:Arial,sans-serif;background:#f4f6fb;margin:0;padding:24px;color:#1e293b}.box{max-width:820px;margin:auto;background:#fff;border-radius:14px;padding:24px;box-shadow:0 6px 24px rgba(0,0,0,.08)}
h1{margin-top:0}table{width:100%;border-collapse:collapse}td{padding:9px 6px;border-bottom:1px solid #eef1f6;font-size:14px;vertical-align:top}.ok{color:#059669;font-weight:700}.bad{color:#dc2626;font-weight:700}small{color:#64748b}</style></head><body><div class="box">
<h1>EddyCare health check</h1>
<table><?php foreach ($rows as [$l, $ok, $d]): ?><tr><td><?= $ok ? '<span class="ok">✔</span>' : '<span class="bad">✘</span>' ?></td><td><?= e($l) ?></td><td><small><?= e($d) ?></small></td></tr><?php endforeach; ?></table>
<p style="margin-top:18px"><small>Send a real test email: add <code>&amp;mailto=your@email.com</code> to this page's address. Delete <code>diagnose.php</code> when you are done.</small></p>
</div></body></html>
