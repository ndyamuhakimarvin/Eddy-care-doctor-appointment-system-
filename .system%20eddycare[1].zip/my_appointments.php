<?php
require 'config.php';
require 'includes/mailer.php';
require_user();

// Allow the patient to cancel their own pending/confirmed appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_id'])) {
    $cid = (int)$_POST['cancel_id'];
    $upd = $pdo->prepare("UPDATE appointments SET status='Cancelled' WHERE id=? AND user_id=? AND status IN ('Pending','Confirmed')");
    $upd->execute([$cid, $_SESSION['user_id']]);
    if ($upd->rowCount() > 0) notify_cancelled($cid);
    flash('success', 'Appointment cancelled.');
    header('Location: my_appointments.php'); exit;
}

$stmt = $pdo->prepare('SELECT a.*, d.name AS doctor, d.specialty FROM appointments a JOIN doctors d ON d.id=a.doctor_id WHERE a.user_id=? ORDER BY a.appointment_date DESC, a.id DESC');
$stmt->execute([$_SESSION['user_id']]);
$rows = $stmt->fetchAll();

$title = 'My Appointments'; $subtitle = 'Track and manage your bookings';
include 'includes/header.php'; ?>
<div class="card-3d">
  <div class="card-head"><h2>Your appointments</h2><a class="btn btn-sm" href="index.php?page=booking"><i class="fa-solid fa-plus"></i> New appointment</a></div>
  <?php if (!$rows): ?>
    <p style="color:var(--muted)">You have no appointments yet. <a href="index.php?page=booking">Book one now</a>.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Ref</th><th>Doctor</th><th>Date &amp; Time</th><th>Status</th><th>Message from hospital</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
      <tr>
        <td><strong><?= e(ref($r['id'])) ?></strong></td>
        <td><?= e($r['doctor']) ?><br><small><?= e($r['specialty']) ?></small></td>
        <td><?= e(date('D, d M Y', strtotime($r['appointment_date']))) ?><br><small><?= e($r['appointment_time']) ?></small></td>
        <td><span class="badge b-<?= e($r['status']) ?>"><?= e($r['status']) ?></span></td>
        <td><?= $r['admin_response'] ? e($r['admin_response']) : '<em style="color:var(--muted)">Awaiting response</em>' ?></td>
        <td><?php if (in_array($r['status'], ['Pending','Confirmed'])): ?>
          <form method="post" onsubmit="return confirm('Cancel this appointment?')"><input type="hidden" name="cancel_id" value="<?= (int)$r['id'] ?>"><button class="btn btn-danger btn-sm">Cancel</button></form>
        <?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>
<?php include 'includes/footer.php';
