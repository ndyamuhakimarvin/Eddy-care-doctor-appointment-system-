<?php
if (session_status() === PHP_SESSION_NONE) session_start();
date_default_timezone_set('Africa/Kampala');

// ---- Database ----
define('DB_HOST', 'localhost');
define('DB_NAME', 'vsyevkyi_zzz_ed');
define('DB_USER', 'vsyevkyi_Morgan');
define('DB_PASS', 'Secret@123$$');

// ---- Email (SMTP via your cPanel mailbox) ----
// NOTE: MAIL_HOST must match the SSL certificate of the mail server.
// Usually: mail.yourdomain.com  (NOT the bare domain — the bare domain
// often doesn't present the mail server's cert and you get a cert error).
define('MAIL_HOST', 's12482.usc1.stableserver.net');
define('MAIL_PORT', 465);                        // 465 = SSL/SMTPS
define('MAIL_USER', 'emmymorgan@altechspheresolns.com');
define('MAIL_PASS', 'Secret@123$$');
define('MAIL_FROM', 'emmymorgan@altechspheresolns.com');
define('MAIL_FROM_NAME', 'EddyCare');
define('MAIL_DEBUG', false);                     // true = print the raw SMTP conversation on screen (troubleshooting only)
define('SITE_URL', 'https://eddycare.altechspheresolns.com');

// ---- Troubleshooting ----
define('APP_DEBUG', true);                       // true = error pages show the real reason. Set to false once everything works.
define('DIAG_KEY', 'ec-a99ecb951e190634');                        // secret for diagnose.php?key=...  (delete diagnose.php when done)

// Some servers lack the mbstring extension; these keep the site from crashing right after login.
if (!function_exists('mb_substr')) { function mb_substr($s, $a, $l = null) { return $l === null ? substr($s, $a) : substr($s, $a, $l); } }
if (!function_exists('mb_strlen')) { function mb_strlen($s) { return strlen($s); } }

// Show a friendly page (and log the details) instead of a blank white 500 error.
set_exception_handler(function ($ex) {
    error_log('EddyCare: ' . $ex);
    if (!headers_sent()) http_response_code(500);
    echo '<div style="font-family:Arial,sans-serif;max-width:640px;margin:12vh auto;padding:26px;border:1px solid #fecaca;background:#fef2f2;border-radius:14px;color:#991b1b">'
       . '<h2 style="margin-bottom:8px">Something went wrong</h2><p>Please go back and try again. If it keeps happening, tell the administrator.</p>'
       . (APP_DEBUG ? '<pre style="margin-top:14px;white-space:pre-wrap;font-size:12px;background:#fff;padding:10px;border-radius:8px">' . htmlspecialchars($ex->getMessage() . '  [' . basename($ex->getFile()) . ':' . $ex->getLine() . ']') . '</pre>' : '')
       . '</div>';
});

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    die('Database connection failed. Check config.php and that you imported database.sql.');
}

require_once __DIR__ . '/includes/theme.php';

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function flash($type, $msg) { $_SESSION['flash'] = ['type' => $type, 'msg' => $msg]; }

function get_flash() {
    if (!empty($_SESSION['flash'])) { $f = $_SESSION['flash']; unset($_SESSION['flash']); return $f; }
    return null;
}

function is_logged_in() { return !empty($_SESSION['user_id']); }
function is_admin() { return is_logged_in() && ($_SESSION['role'] ?? '') === 'admin'; }

function require_user() {
    if (!is_logged_in()) { flash('error', 'Please log in first.'); header('Location: login.php'); exit; }
}
function require_admin() {
    if (!is_admin()) { header('Location: login.php'); exit; }
}

function ref($id) { return 'EC-' . str_pad($id, 5, '0', STR_PAD_LEFT); }

// Time slots offered (must match Mon-Fri 8-6, Sat 9-2 hospital hours)
function all_slots() { return ['09:00 AM','10:00 AM','11:00 AM','02:00 PM','03:00 PM','04:00 PM']; }