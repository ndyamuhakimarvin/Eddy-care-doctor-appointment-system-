<?php
/* Split-screen layout for login/register/verify. Set before including: $title, optional $base, $heading, $lead */
$base    = $base ?? '';
$title   = $title ?? 'Welcome';
$flash   = get_flash();
$heading = $heading ?? 'Healthcare, <span>scheduled simply.</span>';
$lead    = $lead ?? 'Book appointments with specialist doctors, get instant email updates and keep track of every visit in one place.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> &middot; <?= e(setting('system_name')) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?= theme_head() ?>
<link rel="stylesheet" href="<?= $base ?>style.css?v=3">
</head>
<body class="auth-body">
<div class="auth">
  <aside class="auth-side">
    <a class="auth-brand" href="<?= $base ?>index.php"><span class="brand-icon"><i class="fa-solid <?= e(setting('brand_icon')) ?>"></i></span><?= e(setting('system_name')) ?></a>
    <div class="auth-hero">
      <h2><?= $heading ?></h2>
      <p><?= e($lead) ?></p>
      <ul class="auth-features">
        <li><i class="fa-solid fa-calendar-check"></i> Real-time slot availability</li>
        <li><i class="fa-solid fa-envelope-circle-check"></i> Email notifications for patients &amp; doctors</li>
        <li><i class="fa-solid fa-user-doctor"></i> Verified specialist doctors</li>
      </ul>
    </div>
    <small>&copy; <?= date('Y') ?> <?= e(setting('system_name')) ?></small>
  </aside>
  <main class="auth-main"><div class="auth-card">
  <?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?>">
      <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : ($flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info') ?>"></i>
      <div><?= $flash['msg'] ?></div>
    </div>
  <?php endif; ?>
