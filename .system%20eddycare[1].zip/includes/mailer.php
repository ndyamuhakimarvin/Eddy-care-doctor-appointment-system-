<?php
use PHPMailer\PHPMailer\PHPMailer;

require_once __DIR__ . '/../emailphp/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../emailphp/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../emailphp/PHPMailer-master/src/SMTP.php';

$GLOBALS['MAIL_LAST_ERROR'] = '';
/** Why the last send_mail() failed (empty string if it worked). */
function mail_last_error() { return $GLOBALS['MAIL_LAST_ERROR'] ?? ''; }

/** Branded HTML wrapper (table layout + inline CSS so it renders in Gmail/Outlook). */
function mail_layout($heading, $bodyHtml) {
    $p    = function_exists('color_setting') ? color_setting('primary_color') : '#2563eb';
    $name = function_exists('setting') ? e(setting('system_name')) : 'EddyCare';
    $addr = function_exists('setting') ? e(setting('contact_address')) : '';
    $ph   = function_exists('setting') ? e(setting('contact_phone'))   : '';
    $em   = function_exists('setting') ? e(setting('contact_email'))   : '';
    $dark = function_exists('shade') ? shade($p, -0.25) : $p;

    return '<!DOCTYPE html><html><body style="margin:0;padding:0;background:#f4f6fb;font-family:Arial,Helvetica,sans-serif;color:#1e293b">'
      . '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f6fb;padding:28px 12px"><tr><td align="center">'
      . '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 6px 24px rgba(15,23,42,.08)">'
      . '<tr><td style="background:' . $p . ';background-image:linear-gradient(135deg,' . $p . ',' . $dark . ');padding:28px 32px;color:#ffffff">'
      . '<div style="font-size:14px;letter-spacing:.08em;text-transform:uppercase;opacity:.85">' . $name . '</div>'
      . '<div style="font-size:24px;font-weight:700;margin-top:6px">' . e($heading) . '</div></td></tr>'
      . '<tr><td style="padding:30px 32px;font-size:15px;line-height:1.65">' . $bodyHtml . '</td></tr>'
      . '<tr><td style="padding:18px 32px;background:#f8fafc;color:#64748b;font-size:12px;text-align:center;border-top:1px solid #e5e9f2">'
      . $name . ' &middot; ' . $addr . '<br>' . $ph . ' &middot; ' . $em . '</td></tr>'
      . '</table></td></tr></table></body></html>';
}

/**
 * Send one email. Returns true/false and never throws, so a mail problem can't break
 * registration / booking. Set MAIL_DEBUG = true in config.php to see the SMTP conversation.
 */
function send_mail($toEmail, $toName, $subject, $heading, $bodyHtml) {
    $GLOBALS['MAIL_LAST_ERROR'] = '';
    $toEmail = trim((string)$toEmail);
    if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
        $GLOBALS['MAIL_LAST_ERROR'] = 'Invalid or missing recipient address.';
        return false;
    }
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->Port       = MAIL_PORT;
        $mail->SMTPSecure = ((int)MAIL_PORT === 465) ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Timeout    = 20;
        $mail->CharSet    = 'UTF-8';
        $debug = defined('MAIL_DEBUG') && MAIL_DEBUG;
        $mail->SMTPDebug  = $debug ? 2 : 0;
        if ($debug) {
            $mail->Debugoutput = function ($str, $level) {
                error_log('SMTP[' . $level . ']: ' . trim($str));
                echo '<pre style="color:#b91c1c;background:#fef2f2;padding:8px;font-size:11px">' . htmlspecialchars(trim($str)) . '</pre>';
            };
        }
        $fromName = defined('MAIL_FROM_NAME') ? MAIL_FROM_NAME : (function_exists('setting') ? setting('system_name') : 'EddyCare');
        $mail->setFrom(MAIL_FROM, $fromName);
        $mail->addReplyTo(MAIL_FROM, $fromName);
        $mail->addAddress($toEmail, (string)$toName);

        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = mail_layout($heading, $bodyHtml);
        $mail->AltBody = trim(html_entity_decode(strip_tags(preg_replace('#<(br|/p|/tr|/div)[^>]*>#i', "\n", $bodyHtml)), ENT_QUOTES, 'UTF-8'));
        $mail->send();
        return true;
    } catch (Throwable $ex) {
        $GLOBALS['MAIL_LAST_ERROR'] = $mail->ErrorInfo ?: $ex->getMessage();
        error_log('EddyCare mail error to ' . $toEmail . ' | host=' . MAIL_HOST . ':' . MAIL_PORT . ' | ' . $GLOBALS['MAIL_LAST_ERROR']);
        return false;
    }
}

/* ---------- appointment notifications (patients + doctors) ----------
   Every notify_* function is wrapped so an email/database problem can NEVER break booking or login. */

function appt_for_mail($id) {
    global $pdo;
    try {
        $s = $pdo->prepare('SELECT a.*, u.full_name AS patient, u.email AS patient_email, u.phone AS patient_phone,
                                   d.name AS doctor, d.specialty, d.email AS doctor_email
                            FROM appointments a JOIN users u ON u.id=a.user_id JOIN doctors d ON d.id=a.doctor_id WHERE a.id=?');
        $s->execute([(int)$id]);
        return $s->fetch();
    } catch (Throwable $ex) {
        error_log('EddyCare appt_for_mail: ' . $ex->getMessage() . ' (did you run migrate.sql?)');
        return false;
    }
}

function appt_box($a, $forDoctor = false) {
    $row = function ($k, $v) { return '<tr><td style="padding:8px 0;color:#64748b;width:130px">' . $k . '</td><td style="padding:8px 0;font-weight:600">' . $v . '</td></tr>'; };
    $h = '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border:1px solid #e5e9f2;border-radius:12px;margin:18px 0;padding:8px 18px">';
    $h .= $row('Reference', e(ref($a['id'])));
    $h .= $forDoctor ? $row('Patient', e($a['patient']) . '<br><span style="font-weight:400;color:#64748b">' . e($a['patient_phone']) . '</span>')
                     : $row('Doctor', e($a['doctor']) . ' <span style="font-weight:400;color:#64748b">(' . e($a['specialty']) . ')</span>');
    $h .= $row('Date', e(date('l, d M Y', strtotime($a['appointment_date']))));
    $h .= $row('Time', e($a['appointment_time']));
    $h .= $row('Status', e($a['status']));
    if (!empty($a['notes'])) $h .= $row('Notes', nl2br(e($a['notes'])));
    return $h . '</table>';
}

/** After a patient books: tells the patient the date/time to come, and tells the doctor. */
function notify_booking($id) {
    try {
        $a = appt_for_mail($id); if (!$a) return;
        send_mail($a['patient_email'], $a['patient'], 'Appointment request received - ' . ref($a['id']), 'Appointment request received',
            '<p>Hello ' . e($a['patient']) . ',</p><p>We have received your appointment request for <strong>' . e(date('l, d M Y', strtotime($a['appointment_date']))) . ' at ' . e($a['appointment_time'])
            . '</strong>. Our team will review it and you will get another email as soon as it is confirmed.</p>' . appt_box($a));
        send_mail($a['doctor_email'], $a['doctor'], 'New appointment request - ' . ref($a['id']), 'New appointment request',
            '<p>Hello ' . e($a['doctor']) . ',</p><p>A patient has requested an appointment with you. It is awaiting confirmation by the administrator.</p>' . appt_box($a, true));
    } catch (Throwable $ex) { error_log('EddyCare notify_booking: ' . $ex->getMessage()); }
}

/** After the admin changes status/response. Returns true if the patient email went out. */
function notify_status($id) {
    try {
        $a = appt_for_mail($id); if (!$a) return false;
        $primary = function_exists('color_setting') ? color_setting('primary_color') : '#2563eb';
        $msg = $a['admin_response']
            ? '<p style="padding:12px 16px;background:#eff6ff;border-left:4px solid ' . $primary . ';border-radius:8px"><strong>Message from the hospital:</strong><br>' . nl2br(e($a['admin_response'])) . '</p>' : '';
        $lead = $a['status'] === 'Confirmed'
            ? '<p>Good news - your appointment is <strong>confirmed</strong>. Please arrive 10 minutes early on <strong>' . e(date('l, d M Y', strtotime($a['appointment_date']))) . ' at ' . e($a['appointment_time']) . '</strong>.</p>'
            : '<p>There is an update on your appointment.</p>';
        $ok = send_mail($a['patient_email'], $a['patient'], 'Your appointment is ' . $a['status'] . ' - ' . ref($a['id']), 'Appointment ' . $a['status'],
            '<p>Hello ' . e($a['patient']) . ',</p>' . $lead . appt_box($a) . $msg);
        if (in_array($a['status'], ['Confirmed', 'Cancelled'], true)) {
            send_mail($a['doctor_email'], $a['doctor'], 'Appointment ' . $a['status'] . ' - ' . ref($a['id']), 'Appointment ' . $a['status'],
                '<p>Hello ' . e($a['doctor']) . ',</p><p>The following appointment has been marked <strong>' . e($a['status']) . '</strong>.</p>' . appt_box($a, true));
        }
        return $ok;
    } catch (Throwable $ex) { error_log('EddyCare notify_status: ' . $ex->getMessage()); return false; }
}

/** After a patient cancels their own appointment. */
function notify_cancelled($id) {
    try {
        $a = appt_for_mail($id); if (!$a) return;
        send_mail($a['patient_email'], $a['patient'], 'Appointment cancelled - ' . ref($a['id']), 'Appointment cancelled',
            '<p>Hello ' . e($a['patient']) . ',</p><p>Your appointment has been cancelled as requested. You are welcome to book a new time whenever you like.</p>' . appt_box($a));
        send_mail($a['doctor_email'], $a['doctor'], 'Appointment cancelled by patient - ' . ref($a['id']), 'Appointment cancelled',
            '<p>Hello ' . e($a['doctor']) . ',</p><p>The patient cancelled this appointment, so the time slot is free again.</p>' . appt_box($a, true));
    } catch (Throwable $ex) { error_log('EddyCare notify_cancelled: ' . $ex->getMessage()); }
}

/** After feedback is submitted: confirms receipt to the patient (if logged in) and tells the doctor. */
function notify_feedback($userId, $doctorId, $name, $rating, $message) {
    global $pdo;
    try {
        $stars = str_repeat('★', (int)$rating) . str_repeat('☆', 5 - (int)$rating);
        $box = '<table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border:1px solid #e5e9f2;border-radius:12px;margin:18px 0"><tr><td style="padding:16px 18px">'
             . '<div style="font-size:22px;color:#f59e0b;letter-spacing:3px">' . $stars . '</div>'
             . '<div style="margin-top:8px">' . nl2br(e($message)) . '</div></td></tr></table>';
        $doc = null;
        if ($doctorId) { $s = $pdo->prepare('SELECT name, email FROM doctors WHERE id=?'); $s->execute([(int)$doctorId]); $doc = $s->fetch(); }
        if ($userId) {
            $s = $pdo->prepare('SELECT full_name, email FROM users WHERE id=?'); $s->execute([(int)$userId]); $u = $s->fetch();
            if ($u) send_mail($u['email'], $u['full_name'], 'We received your feedback', 'Feedback received',
                '<p>Hello ' . e($u['full_name']) . ',</p><p>Thank you for sharing your experience' . ($doc ? ' about <strong>' . e($doc['name']) . '</strong>' : '') . '. Your feedback has been received and our team will review it.</p>' . $box);
        }
        if ($doc && !empty($doc['email'])) {
            send_mail($doc['email'], $doc['name'], 'New patient feedback', 'New patient feedback',
                '<p>Hello ' . e($doc['name']) . ',</p><p><strong>' . e($name) . '</strong> left feedback about you:</p>' . $box);
        }
    } catch (Throwable $ex) { error_log('EddyCare notify_feedback: ' . $ex->getMessage()); }
}

function notify_welcome($name, $email) {
    try {
        $p = function_exists('color_setting') ? color_setting('primary_color') : '#2563eb';
        send_mail($email, $name, 'Welcome to ' . setting('system_name'), 'Welcome aboard',
            '<p>Hello ' . e($name) . ',</p><p>Your patient account is ready. You can now book appointments with our specialist doctors and track them online.</p>'
            . '<p style="text-align:center;margin:26px 0"><a href="' . e(rtrim(SITE_URL, '/')) . '/login.php" style="background:' . $p . ';color:#fff;padding:13px 28px;border-radius:50px;text-decoration:none;font-weight:700">Log in</a></p>');
    } catch (Throwable $ex) { error_log('EddyCare notify_welcome: ' . $ex->getMessage()); }
}
