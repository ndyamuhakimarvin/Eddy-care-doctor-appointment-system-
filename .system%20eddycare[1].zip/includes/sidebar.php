<?php /* Admin-only sidebar. Included by header.php for pages under /admin/. */
$base   = $base ?? '../';
$script = basename($_SERVER['SCRIPT_NAME']);
$tab    = $_GET['tab'] ?? '';
if (!function_exists('nav_item')) {
    function nav_item($href, $icon, $label, $active = false, $extra = '', $badge = 0) {
        return '<a href="' . $href . '" class="nav-item' . ($active ? ' active' : '') . '"' . $extra . '><i class="fa-solid ' . $icon . '"></i><span>' . e($label) . '</span>'
             . ($badge > 0 ? '<em class="nav-badge">' . (int)$badge . '</em>' : '') . '</a>';
    }
}
$pendingCount = 0;
try { $pendingCount = (int)$pdo->query("SELECT COUNT(*) FROM appointments WHERE status='Pending'")->fetchColumn(); } catch (Throwable $ex) {}
?>
<aside class="sidebar" id="sidebar">
  <a class="brand" href="<?= $base ?>admin/dashboard.php">
    <span class="brand-icon"><i class="fa-solid <?= e(setting('brand_icon')) ?>"></i></span>
    <span class="brand-text"><b><?= e(setting('system_name')) ?></b><small>Admin panel</small></span>
  </a>
  <nav class="nav">
    <div class="nav-label">Administration</div>
    <?= nav_item($base . 'admin/dashboard.php', 'fa-calendar-check', 'Appointments', $script === 'dashboard.php' && $tab !== 'feedback', '', $pendingCount) ?>
    <?= nav_item($base . 'admin/dashboard.php?tab=feedback', 'fa-comments', 'Feedback', $script === 'dashboard.php' && $tab === 'feedback') ?>
    <?= nav_item($base . 'admin/doctors.php', 'fa-user-doctor', 'Doctors', $script === 'doctors.php') ?>
    <?= nav_item($base . 'admin/settings.php', 'fa-sliders', 'Settings', $script === 'settings.php') ?>
    <div class="nav-label">Website</div>
    <?= nav_item($base . 'index.php', 'fa-globe', 'View Website') ?>
  </nav>
  <div class="sidebar-user">
    <span class="avatar"><?= e(strtoupper(mb_substr($_SESSION['name'] ?? 'U', 0, 1))) ?></span>
    <div><b><?= e($_SESSION['name']) ?></b><small><?= e($_SESSION['email'] ?? '') ?></small></div>
    <a href="<?= $base ?>logout.php" title="Log out" class="logout"><i class="fa-solid fa-right-from-bracket"></i></a>
  </div>
</aside>
