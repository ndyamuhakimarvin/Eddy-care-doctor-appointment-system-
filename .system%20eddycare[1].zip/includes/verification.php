<?php
/* Email verification codes for admin accounts (6 digits, 10 min expiry, 5 attempts, 60s resend cooldown). */
require_once __DIR__ . '/mailer.php';

const VERIFY_TTL = 600;
const VERIFY_COOLDOWN = 60;
const VERIFY_MAX_ATTEMPTS = 5;

function verification_row($uid) {
    global $pdo;
    $s = $pdo->prepare('SELECT * FROM email_verification WHERE user_id=? ORDER BY id DESC LIMIT 1');
    $s->execute([(int)$uid]);
    return $s->fetch();
}

function verification_cooldown($uid) {
    $r = verification_row($uid);
    return $r ? max(0, VERIFY_COOLDOWN - (time() - strtotime($r['created_at']))) : 0;
}
function verification_ttl($uid) {
    $r = verification_row($uid);
    return $r ? max(0, strtotime($r['expires_at']) - time()) : 0;
}

/** Create a fresh code, store only its hash, and email it. Returns true if the email was sent. */
function verification_send($user) {
    global $pdo;
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $pdo->prepare('DELETE FROM email_verification WHERE user_id=?')->execute([$user['id']]);
    $pdo->prepare('INSERT INTO email_verification (user_id, code_hash, expires_at, created_at) VALUES (?,?,?,?)')
        ->execute([$user['id'], hash('sha256', $code), date('Y-m-d H:i:s', time() + VERIFY_TTL), date('Y-m-d H:i:s')]);

    $body = '<p>Hello ' . e($user['full_name']) . ',</p>'
          . '<p>Use the code below to verify your email address and finish creating your administrator account.</p>'
          . '<div style="text-align:center;margin:26px 0"><span style="display:inline-block;font-family:Courier New,monospace;font-size:38px;font-weight:700;letter-spacing:10px;'
          . 'padding:16px 26px 16px 36px;background:#f1f5f9;border-radius:12px;color:' . color_setting('primary_color') . '">' . $code . '</span></div>'
          . '<p><strong>This code expires in 10 minutes.</strong></p>'
          . '<p style="color:#94a3b8;font-size:13px">If you did not create this account, you can safely ignore this email.</p>';
    return send_mail($user['email'], $user['full_name'], 'Your verification code: ' . $code, 'Verify your email', $body);
}

/** Returns 'ok', 'invalid', 'expired', 'locked' or 'none'. */
function verification_check($uid, $code) {
    global $pdo;
    $r = verification_row($uid);
    if (!$r) return 'none';
    if ((int)$r['attempts'] >= VERIFY_MAX_ATTEMPTS) return 'locked';
    if (strtotime($r['expires_at']) < time()) return 'expired';
    $pdo->prepare('UPDATE email_verification SET attempts = attempts + 1 WHERE id=?')->execute([$r['id']]);
    if (!hash_equals($r['code_hash'], hash('sha256', preg_replace('/\D/', '', (string)$code)))) return 'invalid';
    $pdo->prepare('UPDATE users SET email_verified=1 WHERE id=?')->execute([$uid]);
    $pdo->prepare('DELETE FROM email_verification WHERE user_id=?')->execute([$uid]);
    return 'ok';
}
