<?php
/* Settings + theme helpers. Settings live in the `settings` table (edit them in Admin > Settings). */

function setting_defaults() {
    return [
        'system_name'   => 'EddyCare',
        'tagline'       => 'Doctor Appointment Booking',
        'brand_icon'    => 'fa-heart-pulse',
        'primary_color' => '#2563eb',
        'accent_color'  => '#10b981',
        'sidebar_bg'    => '#0f172a',
        'sidebar_text'  => '#cbd5e1',
        'page_bg'       => '#f4f6fb',
        'font_family'   => 'Plus Jakarta Sans',
        'contact_phone'  => '+256 780549182',
        'contact_phone2' => '+256 706978597',
        'contact_email'  => 'eddycare@gmail.com',
        'contact_address'=> '123 Eddy Plaza, Kampala City, Plot No 24',
        'hours_weekday'  => 'Mon-Fri: 8:00 AM - 6:00 PM',
        'hours_sat'      => 'Sat: 9:00 AM - 2:00 PM',
        'allow_admin_register' => '1',
    ];
}

function settings() {
    global $pdo;
    static $s = null;
    if ($s === null) {
        $s = setting_defaults();
        try {
            foreach ($pdo->query('SELECT setting_key, setting_value FROM settings') as $r) $s[$r['setting_key']] = $r['setting_value'];
        } catch (Throwable $ex) { /* settings table not created yet: use defaults */ }
    }
    return $s;
}
function setting($key, $default = '') { $s = settings(); return $s[$key] ?? $default; }

function save_setting($key, $value) {
    global $pdo;
    $pdo->prepare('INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)')
        ->execute([$key, $value]);
}

function font_choices() {
    return ['Plus Jakarta Sans','Inter','Poppins','Nunito','DM Sans','Outfit','Montserrat','Open Sans','Lato','Roboto','Raleway','Manrope'];
}
function icon_choices() {
    return ['fa-heart-pulse'=>'Heartbeat','fa-hospital'=>'Hospital','fa-user-doctor'=>'Doctor','fa-stethoscope'=>'Stethoscope','fa-kit-medical'=>'Medical kit','fa-notes-medical'=>'Medical notes','fa-staff-snake'=>'Rod of Asclepius'];
}

function valid_hex($c) { return is_string($c) && preg_match('/^#[0-9a-fA-F]{6}$/', $c); }
function color_setting($key) { $c = setting($key); return valid_hex($c) ? $c : setting_defaults()[$key]; }

function hex_rgb($hex) { $hex = ltrim($hex, '#'); return [hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2))]; }

/** Lighten (+) or darken (-) a hex colour. $p between -1 and 1. */
function shade($hex, $p) {
    $out = '#';
    foreach (hex_rgb($hex) as $c) {
        $v = $p < 0 ? $c * (1 + $p) : $c + (255 - $c) * $p;
        $out .= str_pad(dechex(max(0, min(255, (int)round($v)))), 2, '0', STR_PAD_LEFT);
    }
    return $out;
}

/** Font links + CSS variables. Echo this inside <head> BEFORE style.css. */
function theme_head() {
    $font = setting('font_family');
    if (!in_array($font, font_choices(), true)) $font = 'Plus Jakarta Sans';
    $p = color_setting('primary_color');
    $vars = '--primary:' . $p
          . ';--primary-dark:' . shade($p, -0.15)
          . ';--primary-soft:rgba(' . implode(',', hex_rgb($p)) . ',.10)'
          . ';--accent:' . color_setting('accent_color')
          . ';--bg:' . color_setting('page_bg')
          . ';--sidebar-bg:' . color_setting('sidebar_bg')
          . ';--sidebar-text:' . color_setting('sidebar_text')
          . ";--font:'" . $font . "',system-ui,-apple-system,'Segoe UI',sans-serif";
    return '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         . '<link id="theme-font" href="https://fonts.googleapis.com/css2?family=' . str_replace(' ', '+', $font) . ':wght@400;500;600;700;800&display=swap" rel="stylesheet">'
         . '<style id="theme-vars">:root{' . $vars . '}</style>';
}
