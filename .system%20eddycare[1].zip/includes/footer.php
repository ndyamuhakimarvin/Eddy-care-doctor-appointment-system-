<?php /* Closes what header.php opened. Optional: $page_script (raw <script>…</script> string) */
$inAdmin = $inAdmin ?? (strpos(str_replace('\\', '/', $_SERVER['SCRIPT_NAME']), '/admin/') !== false); ?>
  </main>
  <footer class="site-footer">
    <div class="footer-grid">
      <div><b><?= e(setting('system_name')) ?></b><p><?= e(setting('tagline')) ?> &mdash; your trusted partner in healthcare.</p></div>
      <div><b>Contact</b><p><i class="fa-solid fa-phone"></i> <?= e(setting('contact_phone')) ?><br><i class="fa-solid fa-envelope"></i> <?= e(setting('contact_email')) ?></p></div>
      <div><b>Visit us</b><p><i class="fa-solid fa-location-dot"></i> <?= e(setting('contact_address')) ?></p></div>
    </div>
    <div class="footer-bottom">&copy; <?= date('Y') ?> <?= e(setting('system_name')) ?>. All rights reserved.</div>
  </footer>
<?php if ($inAdmin): ?></div><!-- .main --></div><!-- .app -->
<?php else: ?></div><!-- .site -->
<?php endif; ?>
<script>
(function () {
  var b = document.body, t = document.getElementById('menuToggle'), o = document.getElementById('sidebarOverlay');
  if (t) t.addEventListener('click', function () { b.classList.toggle('nav-open'); });
  if (o) o.addEventListener('click', function () { b.classList.remove('nav-open'); });
  document.querySelectorAll('.sidebar .nav-item, .nav-links .nav-link').forEach(function (a) { a.addEventListener('click', function () { b.classList.remove('nav-open'); }); });
})();
</script>
<?= $page_script ?? '' ?>
</body>
</html>
