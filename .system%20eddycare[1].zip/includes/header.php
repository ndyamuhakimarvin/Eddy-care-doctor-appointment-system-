<?php
/* Shared header. Set before including:  $title (required), $subtitle (optional), $base ('' or '../')
   Admin pages (/admin/) get the sidebar layout; the public site and patient pages get a horizontal navbar. */
$base     = $base ?? '';
$title    = $title ?? setting('system_name');
$subtitle = $subtitle ?? '';
$flash    = get_flash();
$sysName  = setting('system_name');
$inAdmin  = strpos(str_replace('\\', '/', $_SERVER['SCRIPT_NAME']), '/admin/') !== false;
$initial  = is_logged_in() ? strtoupper(mb_substr($_SESSION['name'] ?? 'U', 0, 1)) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($title) ?> &middot; <?= e($sysName) ?></title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<?= theme_head() ?>
<link rel="stylesheet" href="<?= $base ?>style.css?v=3">
</head>
<body>
<?php if ($inAdmin): ?>
<div class="app">
<?php include __DIR__ . '/sidebar.php'; ?>
<div class="sidebar-overlay" id="sidebarOverlay"></div>
<div class="main">
  <header class="topbar">
    <button class="menu-toggle" id="menuToggle" aria-label="Open menu"><i class="fa-solid fa-bars"></i></button>
    <div class="topbar-title">
      <h1 id="pageTitle"><?= e($title) ?></h1>
      <?php if ($subtitle): ?><span><?= e($subtitle) ?></span><?php endif; ?>
    </div>
    <div class="topbar-right">
      <div class="user-chip"><span class="avatar"><?= e($initial) ?></span>
        <div><b><?= e($_SESSION['name']) ?></b><small>Administrator</small></div></div>
    </div>
  </header>
<?php else: ?>
<div class="site">
<?php include __DIR__ . '/navbar.php'; ?>
<?php endif; ?>
  <main class="content">
  <?php if (!$inAdmin && $title !== setting('system_name')): ?>
    <div class="page-heading"><h1 id="pageTitle"><?= e($title) ?></h1><?php if ($subtitle): ?><p><?= e($subtitle) ?></p><?php endif; ?></div>
  <?php endif; ?>
  <?php if ($flash): ?>
    <div class="alert alert-<?= e($flash['type']) ?>">
      <i class="fa-solid <?= $flash['type'] === 'success' ? 'fa-circle-check' : ($flash['type'] === 'error' ? 'fa-circle-exclamation' : 'fa-circle-info') ?>"></i>
      <div><?= $flash['msg'] /* built from escaped values */ ?></div>
    </div>
  <?php endif; ?>
