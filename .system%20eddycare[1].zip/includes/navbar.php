<?php
$base    = $base ?? '';
$script  = basename($_SERVER['SCRIPT_NAME']);
$isIndex = $script === 'index.php';
if (!function_exists('top_link')) {
    // On index.php the page links switch sections in-place; elsewhere they go to index.php
    function top_link($page, $icon, $label) {
        global $isIndex, $base;
        return $isIndex ? '<a href="#" class="nav-link" data-page="' . $page . '"><i class="fa-solid ' . $icon . '"></i> ' . e($label) . '</a>'
                        : '<a href="' . $base . 'index.php?page=' . $page . '" class="nav-link"><i class="fa-solid ' . $icon . '"></i> ' . e($label) . '</a>';
    }
}
?>
<header class="navbar">
  <div class="navbar-inner">
    <a class="site-brand" href="<?= $base ?>index.php">
      <span class="brand-icon"><i class="fa-solid <?= e(setting('brand_icon')) ?>"></i></span>
      <span><b><?= e(setting('system_name')) ?></b><small><?= e(setting('tagline')) ?></small></span>
    </a>

    <nav class="nav-links" id="navLinks">
      <?= top_link('home', 'fa-house', 'Home') ?>
      <?= top_link('doctors', 'fa-user-doctor', 'Doctors') ?>
      <?= top_link('booking', 'fa-calendar-plus', 'Book Appointment') ?>
      <?= top_link('feedback', 'fa-star', 'Feedback') ?>
      <?php if (is_admin()): ?>
        <a href="<?= $base ?>admin/dashboard.php" class="nav-link"><i class="fa-solid fa-gauge"></i> Admin Dashboard</a>
      <?php elseif (is_logged_in()): ?>
        <a href="<?= $base ?>my_appointments.php" class="nav-link<?= $script === 'my_appointments.php' ? ' active' : '' ?>"><i class="fa-solid fa-calendar-days"></i> My Appointments</a>
      <?php endif; ?>

      <div class="nav-auth-mobile">
      <?php if (is_logged_in()): ?>
        <a href="<?= $base ?>logout.php" class="nav-link"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      <?php else: ?>
        <a href="<?= $base ?>login.php" class="nav-link"><i class="fa-solid fa-right-to-bracket"></i> Log in</a>
        <a href="<?= $base ?>register.php" class="nav-link"><i class="fa-solid fa-user-plus"></i> Register</a>
      <?php endif; ?>
      </div>
    </nav>

    <div class="navbar-right">
      <?php if (is_logged_in()): ?>
        <div class="user-chip"><span class="avatar"><?= e(strtoupper(mb_substr($_SESSION['name'] ?? 'U', 0, 1))) ?></span>
          <div><b><?= e(explode(' ', $_SESSION['name'])[0]) ?></b><small><?= is_admin() ? 'Administrator' : 'Patient' ?></small></div></div>
        <a class="btn btn-ghost btn-sm nav-auth-desktop" href="<?= $base ?>logout.php"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
      <?php else: ?>
        <a class="btn btn-ghost btn-sm nav-auth-desktop" href="<?= $base ?>login.php">Log in</a>
        <a class="btn btn-sm nav-auth-desktop" href="<?= $base ?>register.php">Register</a>
      <?php endif; ?>
      <button class="menu-toggle" id="menuToggle" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
    </div>
  </div>
</header>
