<?php
require '../config.php';
require '../includes/verification.php';
if (is_admin()) { header('Location: dashboard.php'); exit; }
if (setting('allow_admin_register') !== '1') { flash('error', 'Admin registration is currently disabled.'); header('Location: login.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if ($name === '' || $email === '' || $pass === '')       $error = 'Name, email and password are required.';
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL))      $error = 'Enter a valid email address.';
    elseif (strlen($pass) < 8)                               $error = 'Password must be at least 8 characters.';
    elseif ($pass !== ($_POST['confirm'] ?? ''))             $error = 'Passwords do not match.';
    else {
        $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$email]);
        if ($chk->fetch()) $error = 'That email is already registered.';
        else {
            $pdo->prepare("INSERT INTO users (full_name,email,phone,password,role,email_verified) VALUES (?,?,?,?, 'admin', 0)")
                ->execute([$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
            $uid = (int)$pdo->lastInsertId();
            $user = ['id' => $uid, 'full_name' => $name, 'email' => $email];
            if (verification_send($user)) {
                $_SESSION['pending_verify'] = $uid;
                flash('success', 'Account created. We emailed a 6-digit code to <strong>' . e($email) . '</strong>.');
                header('Location: verify.php'); exit;
            }
            // Email could not be sent: roll back so the person can try again with the same address
            $pdo->prepare('DELETE FROM users WHERE id=?')->execute([$uid]);
            $error = 'We could not send the verification email. Please check the address and try again, or contact the system owner.' . (APP_DEBUG && mail_last_error() ? ' [' . mail_last_error() . ']' : '');
        }
    }
}
$title = 'Admin Registration'; $base = '../';
$heading = 'Join the <span>admin team.</span>';
$lead = 'Create an administrator account. We will email you a code to confirm your address before you can sign in.';
$page_script = '<script>
function chk(){var v=document.getElementById("pw").value,s=0;if(v.length>=8)s+=25;if(v.length>=12)s+=25;if(/[A-Z]/.test(v)&&/[a-z]/.test(v))s+=25;if(/[0-9\\W]/.test(v))s+=25;
var b=document.getElementById("bar");b.style.width=s+"%";b.style.background=s>=75?"#10b981":s>=50?"#f59e0b":"#ef4444";}
</script>';
include '../includes/auth_head.php'; ?>
  <div class="auth-icon"><i class="fa-solid fa-user-shield"></i></div>
  <h2>Create Admin Account</h2>
  <p class="auth-sub">Full system access &middot; email verification required</p>
  <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($error) ?></div></div><?php endif; ?>
  <form method="post">
    <div class="form-group"><label>Full Name</label><input class="form-control" name="full_name" autocomplete="name" value="<?= e($_POST['full_name'] ?? '') ?>" required></div>
    <div class="form-row">
      <div class="form-group"><label>Email Address</label><input type="email" class="form-control" name="email" autocomplete="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
      <div class="form-group"><label>Phone (optional)</label><input type="tel" class="form-control" name="phone" autocomplete="tel" value="<?= e($_POST['phone'] ?? '') ?>"></div>
    </div>
    <div class="form-group"><label>Password</label>
      <div class="pw"><input type="password" class="form-control" name="password" autocomplete="new-password" id="pw" oninput="chk()" minlength="8" required>
      <button type="button" onclick="var f=document.getElementById('pw');f.type=f.type==='password'?'text':'password'" tabindex="-1"><i class="fa-solid fa-eye"></i></button></div>
      <div class="strength"><i id="bar"></i></div><span class="hint">At least 8 characters</span></div>
    <div class="form-group"><label>Confirm Password</label><input type="password" class="form-control" name="confirm" autocomplete="new-password" required></div>
    <button class="btn btn-block" type="submit"><i class="fa-solid fa-paper-plane"></i> Create Account &amp; Send Code</button>
  </form>
  <p class="auth-links">Already registered? <a href="login.php">Sign in</a></p>
<?php include '../includes/auth_foot.php';
