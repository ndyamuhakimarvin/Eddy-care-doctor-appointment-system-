<?php
require '../config.php';
require_admin();

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? ''); $spec = trim($_POST['specialty'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? '')); $bio = trim($_POST['bio'] ?? '');
    if ($name === '' || $spec === '') $errors[] = 'Doctor name and specialty are required.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email address or leave it empty.';
    if (!$errors) {
        if (!empty($_POST['doctor_id'])) {
            $pdo->prepare('UPDATE doctors SET name=?, specialty=?, email=?, bio=? WHERE id=?')->execute([$name, $spec, $email ?: null, $bio, (int)$_POST['doctor_id']]);
            flash('success', 'Doctor updated.');
        } else {
            $pdo->prepare('INSERT INTO doctors (name, specialty, email, bio) VALUES (?,?,?,?)')->execute([$name, $spec, $email ?: null, $bio]);
            flash('success', 'Doctor added.');
        }
        header('Location: doctors.php'); exit;
    }
}
$doctors = $pdo->query('SELECT * FROM doctors ORDER BY id')->fetchAll();

$base = '../'; $title = 'Doctors'; $subtitle = 'Manage the doctors patients can book';
include '../includes/header.php'; ?>
<?php foreach ($errors as $er): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($er) ?></div></div><?php endforeach; ?>

<div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div>Add each doctor's <strong>email address</strong> so they receive an email whenever a patient books, cancels or the appointment is confirmed.</div></div>

<?php foreach ($doctors as $d): ?>
<div class="card-3d">
  <form method="post">
    <input type="hidden" name="doctor_id" value="<?= (int)$d['id'] ?>">
    <div class="form-row">
      <div class="form-group"><label>Name</label><input class="form-control" name="name" value="<?= e($d['name']) ?>" required></div>
      <div class="form-group"><label>Specialty</label><input class="form-control" name="specialty" value="<?= e($d['specialty']) ?>" required></div>
      <div class="form-group"><label>Email (for notifications)</label><input type="email" class="form-control" name="email" value="<?= e($d['email'] ?? '') ?>" placeholder="doctor@example.com"></div>
    </div>
    <div class="form-group"><label>Short bio</label><textarea class="form-control" name="bio" style="min-height:70px"><?= e($d['bio']) ?></textarea></div>
    <button class="btn btn-sm"><i class="fa-solid fa-floppy-disk"></i> Save doctor</button>
  </form>
</div>
<?php endforeach; ?>

<div class="card-3d" style="border-style:dashed">
  <div class="card-head"><h2><i class="fa-solid fa-plus" style="color:var(--primary)"></i> Add a new doctor</h2></div>
  <form method="post">
    <div class="form-row">
      <div class="form-group"><label>Name</label><input class="form-control" name="name" required></div>
      <div class="form-group"><label>Specialty</label><input class="form-control" name="specialty" required></div>
      <div class="form-group"><label>Email</label><input type="email" class="form-control" name="email"></div>
    </div>
    <div class="form-group"><label>Short bio</label><textarea class="form-control" name="bio" style="min-height:70px"></textarea></div>
    <button class="btn btn-sm btn-secondary"><i class="fa-solid fa-plus"></i> Add doctor</button>
  </form>
</div>
<?php include '../includes/footer.php';
