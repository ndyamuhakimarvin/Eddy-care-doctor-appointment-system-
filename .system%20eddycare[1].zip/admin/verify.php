<?php
require '../config.php';
require '../includes/verification.php';

$uid = (int)($_SESSION['pending_verify'] ?? 0);
if (!$uid) { header('Location: login.php'); exit; }
$st = $pdo->prepare("SELECT id, full_name, email, email_verified FROM users WHERE id=? AND role='admin'");
$st->execute([$uid]);
$user = $st->fetch();
if (!$user) { unset($_SESSION['pending_verify']); header('Location: login.php'); exit; }
if ((int)$user['email_verified']) { unset($_SESSION['pending_verify']); flash('success', 'Your email is already verified. Please log in.'); header('Location: login.php'); exit; }

$error = ''; $info = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['resend'])) {
        $wait = verification_cooldown($uid);
        if ($wait > 0)                    $error = "Please wait {$wait} seconds before requesting another code.";
        elseif (verification_send($user)) $info  = 'A new code has been sent. Any earlier code no longer works.';
        else                              $error = 'We could not send the email. Please try again in a moment.' . (APP_DEBUG && mail_last_error() ? ' [' . mail_last_error() . ']' : '');
    } else {
        $res = verification_check($uid, $_POST['code'] ?? '');
        if ($res === 'ok') {
            unset($_SESSION['pending_verify']);
            flash('success', 'Email verified successfully! You can now log in.');
            header('Location: login.php'); exit;
        }
        $error = [
            'invalid' => 'That code is not correct. Please check it and try again.',
            'expired' => 'That code has expired. Please request a new one.',
            'locked'  => 'Too many wrong attempts. Please request a new code.',
            'none'    => 'No active code found. Please request a new one.',
        ][$res];
    }
}
$ttl = verification_ttl($uid); $cool = verification_cooldown($uid);
[$local, $domain] = explode('@', $user['email'], 2);
$masked = mb_substr($local, 0, 2) . str_repeat('•', max(1, mb_strlen($local) - 2)) . '@' . $domain;

$title = 'Verify Email'; $base = '../';
$heading = 'One last <span>step.</span>';
$lead = 'We sent a 6-digit code to your inbox. Enter it to activate your administrator account.';
$page_script = '<script>
var ttl=' . (int)$ttl . ',cool=' . (int)$cool . ';
var t=document.getElementById("timer"),rb=document.getElementById("resendBtn");
function tick(){
  if(ttl>0){var m=Math.floor(ttl/60),s=ttl%60;t.innerHTML=\'<i class="fa-solid fa-hourglass-half"></i> Code expires in \'+m+":"+(s<10?"0":"")+s;t.style.color="#059669";ttl--;}
  else{t.innerHTML=\'<i class="fa-solid fa-clock"></i> Code expired &mdash; request a new one\';t.style.color="#dc2626";}
  if(cool>0){rb.disabled=true;rb.querySelector("span").textContent="Resend in "+cool+"s";cool--;}
  else{rb.disabled=false;rb.querySelector("span").textContent="Resend code";}
}
tick();setInterval(tick,1000);
</script>';
include '../includes/auth_head.php'; ?>
  <div class="auth-icon"><i class="fa-solid fa-envelope-circle-check"></i></div>
  <h2>Verify your email</h2>
  <p class="auth-sub">Enter the 6-digit code sent to <strong><?= e($masked) ?></strong></p>
  <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($error) ?></div></div><?php endif; ?>
  <?php if ($info): ?><div class="alert alert-success"><i class="fa-solid fa-circle-check"></i><div><?= e($info) ?></div></div><?php endif; ?>
  <form method="post">
    <div class="form-group" style="margin-bottom:0">
      <input class="form-control code-input" name="code" inputmode="numeric" pattern="[0-9]*" maxlength="6" placeholder="••••••" autocomplete="one-time-code" autofocus required>
    </div>
    <div class="timer" id="timer"></div>
    <button class="btn btn-block" type="submit"><i class="fa-solid fa-circle-check"></i> Verify Email</button>
  </form>
  <form method="post" style="margin-top:.7rem">
    <button class="btn btn-ghost btn-block" type="submit" name="resend" value="1" id="resendBtn" formnovalidate><i class="fa-solid fa-rotate-right"></i> <span>Resend code</span></button>
  </form>
  <p class="auth-links"><a href="login.php">Back to login</a></p>
<?php include '../includes/auth_foot.php';
