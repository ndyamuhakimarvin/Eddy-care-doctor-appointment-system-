<?php
require '../config.php';
require '../includes/mailer.php';
require_admin();

$presets = [
    'Ocean'   => ['#2563eb','#10b981','#0f172a','#cbd5e1','#f4f6fb'],
    'Emerald' => ['#059669','#0ea5e9','#064e3b','#d1fae5','#f0fdf4'],
    'Royal'   => ['#7c3aed','#ec4899','#1e1b4b','#e0e7ff','#f5f3ff'],
    'Sunset'  => ['#ea580c','#e11d48','#431407','#fed7aa','#fff7ed'],
    'Slate'   => ['#0f766e','#6366f1','#1e293b','#e2e8f0','#f1f5f9'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    if ($action === 'reset') {
        $pdo->exec('DELETE FROM settings');
        flash('success', 'Settings restored to defaults.');
    } elseif ($action === 'test_mail') {
        $ok = send_mail($_SESSION['email'], $_SESSION['name'], 'Test email from ' . setting('system_name'), 'Email is working',
            '<p>Hello ' . e($_SESSION['name']) . ',</p><p>This is a test message. If you can read it, your SMTP settings in <code>config.php</code> are correct and patients and doctors will receive notifications.</p>');
        $ok ? flash('success', 'Test email sent to <strong>' . e($_SESSION['email']) . '</strong>. Check your inbox (and spam folder).')
            : flash('error', 'The test email failed: <strong>' . e(mail_last_error() ?: 'unknown error') . '</strong><br>Check MAIL_HOST, MAIL_PORT, MAIL_USER and MAIL_PASS in config.php.');
    } else {
        $errs = [];
        $name = trim($_POST['system_name'] ?? '');
        if ($name === '' || mb_strlen($name) > 40) $errs[] = 'System name is required (max 40 characters).';
        $font = $_POST['font_family'] ?? '';
        if (!in_array($font, font_choices(), true)) $errs[] = 'Choose a font from the list.';
        $icon = $_POST['brand_icon'] ?? '';
        if (!isset(icon_choices()[$icon])) $errs[] = 'Choose a logo icon from the list.';
        $vals = [];
        foreach (['primary_color','accent_color','sidebar_bg','sidebar_text','page_bg'] as $k) {
            $c = $_POST[$k] ?? '';
            if (!valid_hex($c)) $errs[] = 'Invalid colour for ' . str_replace('_', ' ', $k) . '. Use a value like #2563eb.';
            $vals[$k] = strtolower($c);
        }
        if ($errs) { flash('error', implode('<br>', array_map('e', $errs))); }
        else {
            $vals += ['system_name' => $name, 'font_family' => $font, 'brand_icon' => $icon,
                'tagline' => mb_substr(trim($_POST['tagline'] ?? ''), 0, 80),
                'contact_phone' => mb_substr(trim($_POST['contact_phone'] ?? ''), 0, 40),
                'contact_phone2' => mb_substr(trim($_POST['contact_phone2'] ?? ''), 0, 40),
                'contact_email' => mb_substr(trim($_POST['contact_email'] ?? ''), 0, 120),
                'contact_address' => mb_substr(trim($_POST['contact_address'] ?? ''), 0, 200),
                'hours_weekday' => mb_substr(trim($_POST['hours_weekday'] ?? ''), 0, 80),
                'hours_sat' => mb_substr(trim($_POST['hours_sat'] ?? ''), 0, 80),
                'allow_admin_register' => isset($_POST['allow_admin_register']) ? '1' : '0'];
            foreach ($vals as $k => $v) save_setting($k, $v);
            flash('success', 'Settings saved. Your new look is live.');
        }
    }
    header('Location: settings.php'); exit;
}

$S = settings();
$base = '../'; $title = 'Settings'; $subtitle = 'Customise the name, colours and fonts of the whole system';

function color_field($key, $label, $hint = '') { global $S;
    $v = valid_hex($S[$key] ?? '') ? $S[$key] : setting_defaults()[$key];
    return '<div class="form-group"><label>' . e($label) . '</label><div class="color-row"><input type="color" data-sync="' . $key . '" value="' . e($v) . '">'
         . '<input class="form-control" name="' . $key . '" id="' . $key . '" value="' . e($v) . '" maxlength="7" pattern="#[0-9a-fA-F]{6}"></div>'
         . ($hint ? '<span class="hint">' . e($hint) . '</span>' : '') . '</div>';
}
include '../includes/header.php'; ?>

<div class="settings-grid">
<div>
<form method="post" id="settingsForm">
  <input type="hidden" name="action" value="save">

  <div class="card-3d">
    <div class="card-head"><div><h2><i class="fa-solid fa-signature" style="color:var(--primary)"></i> Branding</h2><p>Shown in the sidebar, emails, login pages and footer.</p></div></div>
    <div class="form-row">
      <div class="form-group"><label>System name</label><input class="form-control" name="system_name" id="system_name" value="<?= e($S['system_name']) ?>" maxlength="40" required></div>
      <div class="form-group"><label>Tagline</label><input class="form-control" name="tagline" id="tagline" value="<?= e($S['tagline']) ?>" maxlength="80"></div>
    </div>
    <div class="form-group"><label>Logo icon</label>
      <select class="form-control" name="brand_icon" id="brand_icon">
        <?php foreach (icon_choices() as $cls => $lbl): ?><option value="<?= e($cls) ?>" <?= $S['brand_icon'] === $cls ? 'selected' : '' ?>><?= e($lbl) ?></option><?php endforeach; ?>
      </select></div>
  </div>

  <div class="card-3d">
    <div class="card-head"><div><h2><i class="fa-solid fa-palette" style="color:var(--primary)"></i> Colours</h2><p>Changes preview instantly on this page. Click <strong>Save settings</strong> to keep them.</p></div></div>
    <div class="form-group"><label>Quick presets</label>
      <div class="preset-row">
        <?php foreach ($presets as $pn => $pc): ?>
          <button type="button" class="preset" data-preset='<?= e(json_encode($pc)) ?>'><i><?php foreach (array_slice($pc, 0, 3) as $c): ?><b style="background:<?= e($c) ?>"></b><?php endforeach; ?></i><?= e($pn) ?></button>
        <?php endforeach; ?>
      </div></div>
    <div class="form-row">
      <?= color_field('primary_color', 'Primary colour', 'Buttons, links, active menu item') ?>
      <?= color_field('accent_color', 'Accent colour', 'Highlights, gradients, secondary buttons') ?>
      <?= color_field('sidebar_bg', 'Sidebar background') ?>
      <?= color_field('sidebar_text', 'Sidebar text', 'Menu text and icons') ?>
      <?= color_field('page_bg', 'Page background') ?>
    </div>
  </div>

  <div class="card-3d">
    <div class="card-head"><div><h2><i class="fa-solid fa-font" style="color:var(--primary)"></i> Typography</h2><p>Loaded from Google Fonts for the entire system.</p></div></div>
    <div class="form-group"><label>Font family</label>
      <select class="form-control" name="font_family" id="font_family">
        <?php foreach (font_choices() as $f): ?><option <?= $S['font_family'] === $f ? 'selected' : '' ?>><?= e($f) ?></option><?php endforeach; ?>
      </select>
      <div class="font-preview"><strong style="font-size:1.2rem">Book your appointment today</strong><br><span style="color:var(--muted)">The quick brown fox jumps over the lazy dog. 0123456789</span></div>
    </div>
  </div>

  <div class="card-3d">
    <div class="card-head"><div><h2><i class="fa-solid fa-address-book" style="color:var(--primary)"></i> Contact &amp; hours</h2><p>Displayed on the booking page, footer and in emails.</p></div></div>
    <div class="form-row">
      <div class="form-group"><label>Phone 1</label><input class="form-control" name="contact_phone" value="<?= e($S['contact_phone']) ?>"></div>
      <div class="form-group"><label>Phone 2</label><input class="form-control" name="contact_phone2" value="<?= e($S['contact_phone2']) ?>"></div>
      <div class="form-group"><label>Public email</label><input class="form-control" name="contact_email" value="<?= e($S['contact_email']) ?>"></div>
    </div>
    <div class="form-group"><label>Address</label><input class="form-control" name="contact_address" value="<?= e($S['contact_address']) ?>"></div>
    <div class="form-row">
      <div class="form-group"><label>Weekday hours</label><input class="form-control" name="hours_weekday" value="<?= e($S['hours_weekday']) ?>"></div>
      <div class="form-group"><label>Saturday hours</label><input class="form-control" name="hours_sat" value="<?= e($S['hours_sat']) ?>"></div>
    </div>
    <p class="hint">Note: bookable time slots are defined in code (<code>all_slots()</code> in config.php); these fields only change the text shown.</p>
  </div>

  <div class="card-3d">
    <div class="card-head"><div><h2><i class="fa-solid fa-lock" style="color:var(--primary)"></i> Access</h2></div></div>
    <label class="check"><input type="checkbox" name="allow_admin_register" value="1" <?= $S['allow_admin_register'] === '1' ? 'checked' : '' ?>>
      <span><strong>Allow new administrator sign-ups</strong><br><span class="hint">When on, anyone who can open <code>admin/register.php</code> can create an admin account after verifying their email. Turn this off once your team has registered.</span></span></label>
  </div>

  <div class="sticky-save">
    <button type="submit" class="btn"><i class="fa-solid fa-floppy-disk"></i> Save settings</button>
  </div>
</form>
</div>

<div>
  <div class="card-3d">
    <div class="card-head"><h2><i class="fa-solid fa-envelope" style="color:var(--primary)"></i> Email check</h2></div>
    <p style="font-size:.88rem;color:var(--muted);margin-bottom:1rem">Sends a test message to <strong><?= e($_SESSION['email']) ?></strong> using the SMTP details in <code>config.php</code>.</p>
    <form method="post"><input type="hidden" name="action" value="test_mail"><button class="btn btn-secondary btn-block"><i class="fa-solid fa-paper-plane"></i> Send test email</button></form>
  </div>
  <div class="card-3d">
    <div class="card-head"><h2><i class="fa-solid fa-rotate-left" style="color:var(--primary)"></i> Reset</h2></div>
    <p style="font-size:.88rem;color:var(--muted);margin-bottom:1rem">Restore the original name, colours, font and contact details.</p>
    <form method="post" onsubmit="return confirm('Restore all settings to their defaults?')"><input type="hidden" name="action" value="reset"><button class="btn btn-ghost btn-block"><i class="fa-solid fa-rotate-left"></i> Restore defaults</button></form>
  </div>
</div>
</div>

<?php ob_start(); ?>
<script>
(function () {
  var root = document.documentElement.style;
  function rgb(h){h=h.replace('#','');return [parseInt(h.substr(0,2),16),parseInt(h.substr(2,2),16),parseInt(h.substr(4,2),16)];}
  function darken(h,p){return '#'+rgb(h).map(function(c){return ('0'+Math.max(0,Math.round(c*(1-p))).toString(16)).slice(-2);}).join('');}
  var ok = /^#[0-9a-fA-F]{6}$/;
  var map = {primary_color:'--primary', accent_color:'--accent', sidebar_bg:'--sidebar-bg', sidebar_text:'--sidebar-text', page_bg:'--bg'};

  function apply(key, val) {
    if (!ok.test(val)) return;
    root.setProperty(map[key], val);
    if (key === 'primary_color') {
      root.setProperty('--primary-dark', darken(val, .15));
      root.setProperty('--primary-soft', 'rgba(' + rgb(val).join(',') + ',.10)');
    }
  }
  function setField(key, val) {
    var t = document.getElementById(key), p = document.querySelector('[data-sync="' + key + '"]');
    if (t) t.value = val; if (p && ok.test(val)) p.value = val;
    apply(key, val);
  }
  Object.keys(map).forEach(function (key) {
    var t = document.getElementById(key), p = document.querySelector('[data-sync="' + key + '"]');
    t.addEventListener('input', function () { if (ok.test(t.value)) { p.value = t.value; apply(key, t.value); } });
    p.addEventListener('input', function () { t.value = p.value; apply(key, p.value); });
  });
  document.querySelectorAll('.preset').forEach(function (b) {
    b.addEventListener('click', function () {
      var c = JSON.parse(b.dataset.preset), keys = ['primary_color','accent_color','sidebar_bg','sidebar_text','page_bg'];
      keys.forEach(function (k, i) { setField(k, c[i]); });
    });
  });
  // live name / tagline / icon / font preview
  var n = document.getElementById('system_name'), tg = document.getElementById('tagline'), ic = document.getElementById('brand_icon'), fn = document.getElementById('font_family');
  n.addEventListener('input', function () { var b = document.querySelector('.brand-text b'); if (b) b.textContent = n.value; });
  tg.addEventListener('input', function () { var s = document.querySelector('.brand-text small'); if (s) s.textContent = tg.value; });
  ic.addEventListener('change', function () { var i = document.querySelector('.brand-icon i'); if (i) i.className = 'fa-solid ' + ic.value; });
  fn.addEventListener('change', function () {
    var f = fn.value, link = document.getElementById('theme-font');
    link.href = 'https://fonts.googleapis.com/css2?family=' + f.replace(/ /g, '+') + ':wght@400;500;600;700;800&display=swap';
    root.setProperty('--font', "'" + f + "',system-ui,sans-serif");
  });
})();
</script>
<?php $page_script = ob_get_clean(); include '../includes/footer.php';
