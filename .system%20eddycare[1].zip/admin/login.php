<?php
require '../config.php';

// First run: create the default admin if none exists (admin@eddycare.com / Admin@123)
if (!$pdo->query("SELECT COUNT(*) FROM users WHERE role='admin'")->fetchColumn()) {
    $pdo->prepare("INSERT INTO users (full_name,email,phone,password,role,email_verified) VALUES ('Administrator','admin@eddycare.com','0000000000',?, 'admin', 1)")
        ->execute([password_hash('Admin@123', PASSWORD_DEFAULT)]);
}
if (is_admin()) { header('Location: dashboard.php'); exit; }

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
    $stmt->execute([strtolower(trim($_POST['email'] ?? ''))]);
    $u = $stmt->fetch();
    if ($u && password_verify($_POST['password'] ?? '', $u['password'])) {
        if (!(int)$u['email_verified']) {            // correct password but email not verified yet
            $_SESSION['pending_verify'] = (int)$u['id'];
            flash('info', 'Please verify your email address first. Use the code we sent you, or request a new one.');
            header('Location: verify.php'); exit;
        }
        session_regenerate_id(true);
        $_SESSION['user_id'] = $u['id'];
        $_SESSION['name']    = $u['full_name'];
        $_SESSION['email']   = $u['email'];
        $_SESSION['role']    = 'admin';
        header('Location: dashboard.php'); exit;
    }
    $error = 'Incorrect admin email or password.';
}
$title = 'Admin Login'; $base = '../';
$heading = 'Manage every <span>appointment.</span>';
$lead = 'Confirm bookings, respond to patients, manage doctors and customise the whole system from one dashboard.';
include '../includes/auth_head.php'; ?>
  <div class="auth-icon"><i class="fa-solid fa-shield-halved"></i></div>
  <h2>Admin Login</h2>
  <p class="auth-sub">Sign in to the administration area</p>
  <?php if ($error): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($error) ?></div></div><?php endif; ?>
  <form method="post">
    <div class="form-group"><label>Admin Email</label><input type="email" class="form-control" name="email" value="<?= e($_POST['email'] ?? '') ?>" required autofocus></div>
    <div class="form-group"><label>Password</label>
      <div class="pw"><input type="password" class="form-control" name="password" id="pw" required>
      <button type="button" onclick="var f=document.getElementById('pw');f.type=f.type==='password'?'text':'password'" tabindex="-1"><i class="fa-solid fa-eye"></i></button></div></div>
    <button class="btn btn-block" type="submit"><i class="fa-solid fa-right-to-bracket"></i> Login as Admin</button>
  </form>
  <p class="auth-links">
    <?php if (setting('allow_admin_register') === '1'): ?>Need an admin account? <a href="register.php">Register</a><br><?php endif; ?>
    <a href="../login.php" style="font-weight:500">Patient login</a>
  </p>
<?php include '../includes/auth_foot.php';
