<?php
require '../config.php';
require '../includes/mailer.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['appt_id'])) {
        $id = (int)$_POST['appt_id'];
        $status = in_array($_POST['status'], ['Pending','Confirmed','Cancelled','Completed']) ? $_POST['status'] : 'Pending';
        $resp = trim($_POST['admin_response'] ?? '') ?: null;
        $old = $pdo->prepare('SELECT status, admin_response FROM appointments WHERE id=?'); $old->execute([$id]); $old = $old->fetch();
        $pdo->prepare('UPDATE appointments SET status=?, admin_response=? WHERE id=?')->execute([$status, $resp, $id]);
        $msg = 'Appointment updated. The patient will see your response.';
        if ($old && ($old['status'] !== $status || (string)$old['admin_response'] !== (string)$resp)) {
            $msg .= notify_status($id) ? ' An email update was sent to the patient.' : ' (The email could not be sent - check the mail settings.)';
        }
        flash('success', $msg);
    } elseif (isset($_POST['delete_feedback'])) {
        $pdo->prepare('DELETE FROM feedback WHERE id=?')->execute([(int)$_POST['delete_feedback']]);
        flash('success', 'Feedback deleted.');
    }
    header('Location: dashboard.php' . (isset($_POST['delete_feedback']) ? '?tab=feedback' : '')); exit;
}

$tab = ($_GET['tab'] ?? '') === 'feedback' ? 'feedback' : 'appointments';
$filter = $_GET['status'] ?? '';
$counts = $pdo->query("SELECT status, COUNT(*) c FROM appointments GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn();

$sql = 'SELECT a.*, u.full_name, u.email, u.phone, d.name AS doctor, d.specialty
        FROM appointments a JOIN users u ON u.id=a.user_id JOIN doctors d ON d.id=a.doctor_id';
$params = [];
if (in_array($filter, ['Pending','Confirmed','Cancelled','Completed'])) { $sql .= ' WHERE a.status=?'; $params[] = $filter; }
$stmt = $pdo->prepare($sql . ' ORDER BY a.appointment_date DESC, a.id DESC');
$stmt->execute($params);
$appts = $stmt->fetchAll();

$fbs = $pdo->query('SELECT f.*, d.name AS doctor FROM feedback f LEFT JOIN doctors d ON d.id=f.doctor_id ORDER BY f.created_at DESC')->fetchAll();

$base = '../'; $title = $tab === 'feedback' ? 'Patient Feedback' : 'Appointments'; $subtitle = 'Admin dashboard';
include '../includes/header.php'; ?>

<div class="stats">
  <div class="stat"><div class="stat-icon"><i class="fa-solid fa-calendar-check"></i></div><div><b><?= (int)array_sum($counts) ?></b><span>Total appointments</span></div></div>
  <div class="stat"><div class="stat-icon"><i class="fa-solid fa-hourglass-half"></i></div><div><b><?= (int)($counts['Pending'] ?? 0) ?></b><span>Pending</span></div></div>
  <div class="stat"><div class="stat-icon"><i class="fa-solid fa-circle-check"></i></div><div><b><?= (int)($counts['Confirmed'] ?? 0) ?></b><span>Confirmed</span></div></div>
  <div class="stat"><div class="stat-icon"><i class="fa-solid fa-users"></i></div><div><b><?= (int)$totalUsers ?></b><span>Registered patients</span></div></div>
</div>

<?php if ($tab === 'appointments'): ?>
  <div class="card-3d">
    <div class="card-head"><h2>Appointments</h2>
      <div class="pills">
        <a class="pill <?= $filter === '' ? 'on' : '' ?>" href="dashboard.php">All</a>
        <?php foreach (['Pending','Confirmed','Cancelled','Completed'] as $s): ?><a class="pill <?= $filter === $s ? 'on' : '' ?>" href="?status=<?= $s ?>"><?= $s ?></a><?php endforeach; ?>
      </div>
    </div>
    <div class="table-wrap">
    <table>
      <thead><tr><th>Ref</th><th>Patient</th><th>Doctor</th><th>Date &amp; Time</th><th>Notes</th><th style="min-width:230px">Status &amp; response to patient</th></tr></thead>
      <tbody>
      <?php if (!$appts): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No appointments found.</td></tr><?php endif; ?>
      <?php foreach ($appts as $a): ?>
      <tr>
        <td><strong><?= e(ref($a['id'])) ?></strong></td>
        <td><strong><?= e($a['full_name']) ?></strong><br><small><?= e($a['email']) ?><br><?= e($a['phone']) ?></small></td>
        <td><?= e($a['doctor']) ?><br><small><?= e($a['specialty']) ?></small></td>
        <td><?= e(date('D, d M Y', strtotime($a['appointment_date']))) ?><br><small><?= e($a['appointment_time']) ?></small></td>
        <td><?= e($a['notes']) ?></td>
        <td>
          <form method="post">
            <input type="hidden" name="appt_id" value="<?= (int)$a['id'] ?>">
            <select name="status" class="form-control" style="margin-bottom:.4rem">
              <?php foreach (['Pending','Confirmed','Cancelled','Completed'] as $s): ?>
                <option <?= $a['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
              <?php endforeach; ?>
            </select>
            <input name="admin_response" class="form-control" style="margin-bottom:.5rem" placeholder="Message to patient" value="<?= e($a['admin_response']) ?>">
            <button class="btn btn-sm"><i class="fa-solid fa-floppy-disk"></i> Save &amp; notify</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
<?php else: ?>
  <div class="card-3d">
    <div class="card-head"><h2>Patient Feedback</h2></div>
    <div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>Name</th><th>Doctor</th><th>Rating</th><th>Message</th><th></th></tr></thead>
      <tbody>
      <?php if (!$fbs): ?><tr><td colspan="6" style="text-align:center;color:var(--muted);padding:2rem">No feedback yet.</td></tr><?php endif; ?>
      <?php foreach ($fbs as $fb): ?>
      <tr>
        <td><?= e(date('d M Y', strtotime($fb['created_at']))) ?></td>
        <td><?= e($fb['name']) ?></td>
        <td><?= e($fb['doctor'] ?? '-') ?></td>
        <td class="stars"><?= str_repeat('★', (int)$fb['rating']) ?></td>
        <td><?= e($fb['message']) ?></td>
        <td><form method="post" onsubmit="return confirm('Delete this feedback?')"><input type="hidden" name="delete_feedback" value="<?= (int)$fb['id'] ?>"><button class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button></form></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
<?php endif; ?>
<?php include '../includes/footer.php';
