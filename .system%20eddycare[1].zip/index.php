<?php
require 'config.php';
$doctors = $pdo->query('SELECT * FROM doctors ORDER BY id')->fetchAll();
$recent  = $pdo->query('SELECT name, rating, message FROM feedback ORDER BY created_at DESC LIMIT 5')->fetchAll();
$startPage = $_GET['page'] ?? 'home';
if (!in_array($startPage, ['home','doctors','booking','feedback'])) $startPage = 'home';
$icons = ['Cardiologist'=>'🫀','Neurologist'=>'🧠','Pediatrician'=>'👶','Dentist'=>'🦷'];
function stars($r) { $f = (int)round($r); return str_repeat('★', $f) . str_repeat('☆', 5 - $f); }

$titles = ['home'=>'Welcome','doctors'=>'Our Doctors','booking'=>'Book Appointment','feedback'=>'Feedback'];
$title = setting('system_name'); $subtitle = '';
include 'includes/header.php';
?>

<!-- HOME -->
<section id="home" class="page">
  <div class="hero">
    <h1>Find &amp; Book Appointments with Top Doctors</h1>
    <p>Experience seamless healthcare with our modern booking system. Connect with specialized doctors and schedule appointments at your convenience.</p>
    <div class="hero-actions">
      <a href="#" class="btn btn-light" data-page="doctors"><i class="fa-solid fa-user-doctor"></i> Find Doctors</a>
      <a href="#" class="btn btn-outline" data-page="booking"><i class="fa-solid fa-calendar-plus"></i> Book Now</a>
    </div>
  </div>
  <div class="card-3d">
    <div class="card-head"><h2>Why Choose <?= e(setting('system_name')) ?>?</h2></div>
    <div class="grid">
      <div class="feature"><i class="fa-solid fa-bolt"></i><h3>Easy Booking</h3><p>Book appointments in just a few clicks with our intuitive interface.</p></div>
      <div class="feature"><i class="fa-solid fa-user-shield"></i><h3>Verified Doctors</h3><p>All our doctors are thoroughly verified and highly qualified.</p></div>
      <div class="feature"><i class="fa-solid fa-headset"></i><h3>24/7 Support</h3><p>Our support team is available round the clock to assist you.</p></div>
      <div class="feature"><i class="fa-solid fa-envelope-circle-check"></i><h3>Email Updates</h3><p>You and your doctor are notified by email at every step.</p></div>
    </div>
  </div>
  <div class="card-3d">
    <div class="card-head"><h2>Our Specialties</h2></div>
    <div class="grid">
      <?php foreach ($doctors as $d): ?>
        <div class="specialty"><span class="emoji"><?= $icons[$d['specialty']] ?? '🩺' ?></span><h3><?= e($d['specialty']) ?></h3></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- DOCTORS -->
<section id="doctors" class="page">
  <div class="doctor-grid">
    <?php foreach ($doctors as $d): ?>
    <div class="doctor-card">
      <div class="doctor-image">
        <?php if ($d['image'] && file_exists(__DIR__ . '/img/' . $d['image'])): ?>
          <img src="img/<?= e($d['image']) ?>" alt="<?= e($d['name']) ?>">
        <?php else: ?><?= $icons[$d['specialty']] ?? '🩺' ?><?php endif; ?>
      </div>
      <h2><?= e($d['name']) ?></h2>
      <span class="doctor-specialty"><?= e($d['specialty']) ?></span>
      <div class="rating"><span class="stars"><?= stars($d['rating']) ?></span><span><?= e($d['rating']) ?> (<?= e($d['reviews']) ?> reviews)</span></div>
      <p class="doctor-bio"><?= e($d['bio']) ?></p>
      <a href="#" class="btn" data-page="booking" data-doctor="<?= (int)$d['id'] ?>"><i class="fa-solid fa-calendar-plus"></i> Book Appointment</a>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- BOOKING -->
<section id="booking" class="page">
  <?php if (!is_logged_in()): ?>
    <div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div>Please <a href="login.php"><strong>log in</strong></a> or <a href="register.php"><strong>create an account</strong></a> to book an appointment.</div></div>
  <?php elseif (is_admin()): ?>
    <div class="alert alert-info"><i class="fa-solid fa-circle-info"></i><div>You are logged in as admin. Use the <a href="admin/dashboard.php"><strong>dashboard</strong></a> to manage appointments.</div></div>
  <?php else: ?>
  <form action="book.php" method="post" id="booking-form">
    <div class="card-3d">
      <div class="card-head"><h2><i class="fa-solid fa-user-doctor" style="color:var(--primary)"></i> Select Doctor</h2></div>
      <div class="form-group" style="margin:0">
        <select class="form-control" name="doctor_id" id="doctor-select" required>
          <option value="">Select a doctor</option>
          <?php foreach ($doctors as $d): ?>
            <option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?> - <?= e($d['specialty']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="card-3d">
      <div class="card-head"><h2><i class="fa-solid fa-clock" style="color:var(--primary)"></i> Available Timings</h2></div>
      <div class="form-group">
        <label for="appointment-date">Appointment Date</label>
        <input type="date" class="form-control" name="appointment_date" id="appointment-date" required>
      </div>
      <label class="form-label">Available Time Slots</label>
      <div class="timings-grid" id="slots">
        <?php foreach (all_slots() as $s): ?><div class="time-slot" data-time="<?= e($s) ?>"><?= e($s) ?></div><?php endforeach; ?>
      </div>
      <input type="hidden" name="appointment_time" id="appointment-time">
    </div>
    <div class="card-3d">
      <div class="card-head"><h2><i class="fa-solid fa-id-card" style="color:var(--primary)"></i> Your Information</h2></div>
      <div class="form-row">
        <div class="form-group"><label>Full Name</label><input class="form-control" value="<?= e($_SESSION['name']) ?>" readonly></div>
        <div class="form-group"><label>Email Address</label><input class="form-control" value="<?= e($_SESSION['email']) ?>" readonly></div>
      </div>
      <div class="form-group"><label>Additional Notes (Optional)</label><textarea class="form-control" name="notes" placeholder="Any specific concerns or notes for the doctor"></textarea></div>
      <button type="submit" class="btn"><i class="fa-solid fa-check"></i> Confirm Appointment</button>
    </div>
  </form>
  <?php endif; ?>
  <div class="card-3d">
    <div class="card-head"><h2>For Customer Care Services</h2></div>
    <div class="contact-info">
      <div class="contact-item"><div class="contact-icon"><i class="fa-solid fa-phone"></i></div><div><small>Phone</small><?= e(setting('contact_phone')) ?><br><?= e(setting('contact_phone2')) ?></div></div>
      <div class="contact-item"><div class="contact-icon"><i class="fa-solid fa-envelope"></i></div><div><small>Email</small><?= e(setting('contact_email')) ?></div></div>
      <div class="contact-item"><div class="contact-icon"><i class="fa-solid fa-building"></i></div><div><small>Address</small><?= e(setting('contact_address')) ?></div></div>
      <div class="contact-item"><div class="contact-icon"><i class="fa-solid fa-clock"></i></div><div><small>Hospital Hours</small><?= e(setting('hours_weekday')) ?><br><?= e(setting('hours_sat')) ?></div></div>
    </div>
  </div>
</section>

<!-- FEEDBACK -->
<section id="feedback" class="page">
  <div class="card-3d">
    <div class="card-head"><div><h2>Submit Feedback</h2><p>We value your opinion. Please share your experience with our services to help us improve.</p></div></div>
    <form action="feedback_submit.php" method="post">
      <div class="form-row">
        <div class="form-group"><label>Your Name</label><input class="form-control" name="name" value="<?= is_logged_in() ? e($_SESSION['name']) : '' ?>" required></div>
        <div class="form-group"><label>Doctor (Optional)</label>
          <select class="form-control" name="doctor_id"><option value="">Select a doctor</option>
            <?php foreach ($doctors as $d): ?><option value="<?= (int)$d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="form-group"><label>Overall Rating</label>
        <div class="rating-input">
          <?php for ($i = 5; $i >= 1; $i--): ?>
            <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= $i == 5 ? 'required' : '' ?>><label for="star<?= $i ?>">★</label>
          <?php endfor; ?>
        </div></div>
      <div class="form-group"><label>Your Feedback</label><textarea class="form-control" name="message" placeholder="Please share your experience with us..." required></textarea></div>
      <button type="submit" class="btn"><i class="fa-solid fa-paper-plane"></i> Submit Feedback</button>
    </form>
  </div>
  <div class="card-3d">
    <div class="card-head"><h2>Recent Patient Feedback</h2></div>
    <div style="display:grid;gap:1rem">
      <?php if (!$recent): ?><p style="color:var(--muted)">No feedback yet. Be the first!</p><?php endif; ?>
      <?php foreach ($recent as $f): ?>
        <div class="review">
          <div class="review-head"><strong><?= e($f['name']) ?></strong><span class="stars"><?= stars($f['rating']) ?></span></div>
          <p>"<?= e($f['message']) ?>"</p>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<?php ob_start(); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
  const triggers = document.querySelectorAll('[data-page]');
  const pages = document.querySelectorAll('.page');
  const titles = <?= json_encode($titles) ?>;
  const pageTitle = document.getElementById('pageTitle');

  function show(pageId) {
    pages.forEach(p => p.classList.toggle('active', p.id === pageId));
    triggers.forEach(l => { if (l.classList.contains('nav-link')) l.classList.toggle('active', l.dataset.page === pageId); });
    document.title = (titles[pageId] || '') + ' | ' + <?= json_encode(setting('system_name')) ?>;
    window.scrollTo(0, 0);
  }
  triggers.forEach(link => link.addEventListener('click', function (e) {
    e.preventDefault();
    show(this.dataset.page);
    if (this.dataset.doctor) {
      const sel = document.getElementById('doctor-select');
      if (sel) { sel.value = this.dataset.doctor; loadSlots(); }
    }
  }));
  show(<?= json_encode($startPage) ?>);

  const dateInput = document.getElementById('appointment-date');
  const doctorSel = document.getElementById('doctor-select');
  const timeInput = document.getElementById('appointment-time');
  const slotEls = document.querySelectorAll('.time-slot');

  if (dateInput) {
    dateInput.min = new Date().toISOString().split('T')[0];
    slotEls.forEach(slot => slot.addEventListener('click', function () {
      if (this.classList.contains('taken')) return;
      slotEls.forEach(s => s.classList.remove('selected'));
      this.classList.add('selected');
      timeInput.value = this.dataset.time;
    }));
    dateInput.addEventListener('change', loadSlots);
    doctorSel.addEventListener('change', loadSlots);

    document.getElementById('booking-form').addEventListener('submit', function (e) {
      if (!timeInput.value) { e.preventDefault(); alert('Please select a time slot.'); }
    });
  }

  function loadSlots() {
    if (!doctorSel.value || !dateInput.value) return;
    timeInput.value = '';
    slotEls.forEach(s => s.classList.remove('selected', 'taken'));
    fetch('slots.php?doctor_id=' + encodeURIComponent(doctorSel.value) + '&date=' + encodeURIComponent(dateInput.value))
      .then(r => r.json())
      .then(taken => slotEls.forEach(s => { if (taken.includes(s.dataset.time)) s.classList.add('taken'); }));
  }
});
</script>
<?php $page_script = ob_get_clean(); include 'includes/footer.php';
