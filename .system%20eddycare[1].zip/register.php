<?php
require 'config.php';
require 'includes/mailer.php';
if (is_logged_in()) { header('Location: index.php'); exit; }
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name  = trim($_POST['full_name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = trim($_POST['phone'] ?? '');
    $pass  = $_POST['password'] ?? '';
    if ($name === '')                                $errors[] = 'Full name is required.';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL))  $errors[] = 'Enter a valid email address.';
    if ($phone === '')                               $errors[] = 'Phone number is required.';
    if (strlen($pass) < 6)                           $errors[] = 'Password must be at least 6 characters.';
    if ($pass !== ($_POST['confirm'] ?? ''))         $errors[] = 'Passwords do not match.';
    if (!$errors) {
        $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$email]);
        if ($chk->fetch()) $errors[] = 'That email is already registered.';
        else {
            $pdo->prepare('INSERT INTO users (full_name,email,phone,password) VALUES (?,?,?,?)')
                ->execute([$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT)]);
            notify_welcome($name, $email);
            flash('success', 'Account created! You can now log in.');
            header('Location: login.php'); exit;
        }
    }
}
$title = 'Register'; include 'includes/auth_head.php'; ?>
  <div class="auth-icon"><i class="fa-solid fa-user-plus"></i></div>
  <h2>Create an Account</h2>
  <p class="auth-sub">It takes less than a minute</p>
  <?php foreach ($errors as $er): ?><div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i><div><?= e($er) ?></div></div><?php endforeach; ?>
  <form method="post">
    <div class="form-group"><label>Full Name</label><input class="form-control" name="full_name" autocomplete="name" value="<?= e($_POST['full_name'] ?? '') ?>" required></div>
    <div class="form-row">
      <div class="form-group"><label>Email</label><input type="email" class="form-control" name="email" autocomplete="email" value="<?= e($_POST['email'] ?? '') ?>" required></div>
      <div class="form-group"><label>Phone</label><input type="tel" class="form-control" name="phone" autocomplete="tel" value="<?= e($_POST['phone'] ?? '') ?>" required></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Password</label><input type="password" class="form-control" name="password" autocomplete="new-password" required></div>
      <div class="form-group"><label>Confirm Password</label><input type="password" class="form-control" name="confirm" autocomplete="new-password" required></div>
    </div>
    <button class="btn btn-block" type="submit"><i class="fa-solid fa-user-plus"></i> Register</button>
  </form>
  <p class="auth-links">Already have an account? <a href="login.php">Log in</a></p>
<?php include 'includes/auth_foot.php';
